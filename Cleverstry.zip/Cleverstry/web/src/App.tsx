import React from 'react';
import LinksRoutes from './routes'
import './styles/global.css'


function App() {
  return (
    <LinksRoutes/>
  );
}

export default App;
