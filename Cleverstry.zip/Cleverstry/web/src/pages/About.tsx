import Sidebar from "../components/Sidebar";
import Hero from "../components/Hero";
import Footer from "../components/Footer";
import "../styles/pages/wq-page.css"
import "../styles/global.css"
export default function About() {
        return(
            <div className="about-wrapper"></div>
    
        )
    
}