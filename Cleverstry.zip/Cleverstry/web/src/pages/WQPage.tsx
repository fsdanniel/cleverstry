import Sidebar from "../components/Sidebar";
import Hero from "../components/Hero";
import Footer from "../components/Footer";
import "../styles/pages/wq-page.css"
import "../styles/global.css"
export default function WQPage() {
    return (
        <div id="wq-about-wrapper"  className="page">

        
        <Hero/>
<Sidebar/>
<Footer/>
</div>
    )
}