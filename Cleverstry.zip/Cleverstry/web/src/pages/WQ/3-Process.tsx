export default function Process() {
    return(
        <div className="process-wrapper"></div>

    )
}