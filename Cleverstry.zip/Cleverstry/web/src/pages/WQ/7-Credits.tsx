export default function Credits() {
    return(
        <div className="credits-wrapper"></div>

    )
}