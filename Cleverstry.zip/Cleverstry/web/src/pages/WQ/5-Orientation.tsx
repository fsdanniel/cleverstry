export default function Orientation() {
    return(
        <div className="orientation-wrapper"></div>

    )
}