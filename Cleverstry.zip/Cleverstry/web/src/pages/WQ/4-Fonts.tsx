export default function Fonts() {
    return(
        <div className="fonts-wrapper"></div>

    )
}