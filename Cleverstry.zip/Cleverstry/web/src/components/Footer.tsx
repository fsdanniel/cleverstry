import { Link } from "react-router-dom";
import '../styles/components/footer.css'
export default function Footer(){
    return(
<footer className="footer-area">
    <h1>Clevesrtry™</h1>
    <p>@fsdanniel</p>
</footer>
    )}